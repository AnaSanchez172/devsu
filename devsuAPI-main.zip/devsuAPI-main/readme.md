INSTRUCCIONES PASO A PASO DE EJECUCION

1. git clone 
2. Ejecutar feature con cucumber o a su vez la clase AppTest.java




VERSIONES DE LAS TECNOLOGIAS A USAR

• SerenityBDD
• Cucumber
• Gradle versión: 7.6.1
• IDE: IntelliJ IDEA
• JDK: 1.8
• Maven versión: 3.9.1
